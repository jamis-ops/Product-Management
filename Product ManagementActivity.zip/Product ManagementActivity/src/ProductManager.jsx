import { useState } from "react";
import ProductItem from "./ProductItem";

export default function ProductManager({ products, addProduct }) {
  const [filter, setFilter] = useState("All");

  const filteredProducts =
    filter === "All" ? products : products.filter((p) => p.stock === filter);

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const price = parseFloat(e.target.price.value);
    const stock = e.target.stock.value;

    // Check for valid input before adding product
    if (!name || isNaN(price) || !stock) {
      alert("Please provide valid product details!");
      return;
    }

    addProduct(name, price, stock);
    e.target.reset();
  };

  return (
    <div className="w-full max-w-6xl bg-black p-8 rounded-lg shadow-lg mx-auto">
      {/* Filter Buttons */}
      <div className="flex justify-center gap-4 mb-6">
        {["All", "In Stock", "Out of Stock"].map((status) => (
          <button
            key={status}
            className={`px-5 py-2 rounded-full text-sm font-semibold ${
              filter === status
                ? "bg-green-500 text-white"
                : "bg-green-100 text-green-700 hover:bg-green-200"
            }`}
            onClick={() => setFilter(status)}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Product List */}
      <div className="grid grid-cols-2 gap-4">
        {filteredProducts.map((product) => (
          <ProductItem key={product.id} product={product} />
        ))}
      </div>

      {/* Add Product Form */}
      <form onSubmit={handleSubmit} className="mt-8 bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Add Product</h2>
        <div className="mb-6">
          <input
            type="text"
            name="name"
            placeholder="Product Name"
            required
            className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        <div className="mb-6">
          <input
            type="number"
            name="price"
            placeholder="Price"
            required
            className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        <div className="mb-6">
          <select
            name="stock"
            required
            className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="In Stock">In Stock</option>
            <option value="Out of Stock">Out of Stock</option>
          </select>
        </div>
        <button
          type="submit"
          className="w-full bg-green-500 text-white p-3 rounded hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500"
        >
          Add Product
        </button>
      </form>
    </div>
  );
}
