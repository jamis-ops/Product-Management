export default function ProductItem({ product }) {
  return (
    <div className="flex justify-between items-center p-6 rounded-lg shadow-md bg-black hover:shadow-lg transition-shadow duration-300">
      <div>
        <h3 className="text-xl font-semibold text-green-800">{product.name}</h3>
        <p className="text-green-600">${product.price.toFixed(2)}</p>
      </div>
      <span
        className={`px-4 py-2 rounded-full text-sm font-bold ${
          product.stock === "In Stock"
            ? "bg-green-200 text-green-900"
            : "bg-red-200 text-red-900"
        }`}
      >
        {product.stock}
      </span>
    </div>
  );
}

  