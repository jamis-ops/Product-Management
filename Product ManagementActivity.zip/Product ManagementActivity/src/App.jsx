import { useState } from "react";
import ProductManager from "./ProductManager";

export default function App() {
  const [products, setProducts] = useState([
    { id: 1, name: "Laptop", price: 1200, stock: "In Stock" },
    { id: 2, name: "Smartphone", price: 800, stock: "Out of Stock" },
    { id: 3, name: "Headphones", price: 200, stock: "In Stock" },
  ]);

  const addProduct = (name, price, stock) => {
    const newProduct = {
      id: products.length + 1,
      name,
      price: Number(price),
      stock,
    };
    setProducts([...products, newProduct]);
  };

  return (
    <div className="min-h-screen bg-pastelYellow p-8 flex flex-col items-center">
      <h1 className="text-4xl font-bold text-pastelPurple mb-6">Product Management</h1>
      <ProductManager products={products} addProduct={addProduct} />
    </div>
  );
}